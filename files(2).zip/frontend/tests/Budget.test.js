import { render, fireEvent } from "@testing-library/react";
import Budget from "../components/Budget";

test("renders budget form and adds budget", async () => {
  const { getByPlaceholderText, getByText } = render(<Budget />);
  const categoryInput = getByPlaceholderText("Category");
  const limitInput = getByPlaceholderText("Limit");
  const addButton = getByText("Add Budget");

  fireEvent.change(categoryInput, { target: { value: "Food" } });
  fireEvent.change(limitInput, { target: { value: "500" } });
  fireEvent.click(addButton);

  const budgetItem = await getByText("Food: $500");
  expect(budgetItem).toBeInTheDocument();
});