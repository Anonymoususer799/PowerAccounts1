import React from "react";

function Dashboard() {
  return (
    <div>
      <h1>Dashboard</h1>
      <p>Welcome to your accounting dashboard!</p>
    </div>
  );
}

export default Dashboard;